# README - Peha PHC versie 0.1.1

Home Assistant-integratie voor de Peha PHC-bus. Commando's gaan via de STM-stuureenheid (USB-kabel, met C0/C1-framing en escaping). Alles wat op de bus gebeurt, komt binnen via de RS485-busdongle en gaat door de parser van de integratie.

Repository: https://github.com/v12345vtm/PEHACustomComponent_HA

## Installatie

Kopieer de map `custom_components/peha_phc` naar de map `custom_components` van Home Assistant, of voeg de repository toe in HACS als aangepaste repository van het type integratie. Stop Node-RED zolang de poorten door de integratie gebruikt worden, want twee programma's die tegelijk van dezelfde poort lezen, halen elkaars data weg.

Vanaf versie 0.1.0 volstaat het om de map te vervangen en Home Assistant te herstarten. Bestaande entiteiten houden hun id, en de nieuwe entiteiten komen er vanzelf bij. Hebt u een oudere, niet-officiële versie draaien, verwijder die dan eerst via Instellingen, Apparaten en diensten.

Voeg de integratie toe via Integratie toevoegen, Peha PHC. De standaardpoorten zijn `/dev/ttyACM0` voor de USB-kabel en `/dev/ttyUSB0` voor de busdongle. Modules voegt u toe via Configureren, met alleen een PHC-nummer en een naam.

## Hub-apparaat: poorten en logs

Het apparaat Peha PHC bevat vier entiteiten die niet bij een module horen. Poort USB-kabel (STM) en Poort busdongle (RS485) zijn twee schakelaars die standaard aan staan. Zet u er één uit, dan wordt die poort echt gesloten, zodat een ander programma hem kan gebruiken. De stand blijft bewaard na een herstart. Zolang een van beide poorten dicht is, zijn de modules onbeschikbaar en geven commando's een duidelijke melding.

Verstuurde pakketten (USB-kabel) toont de C0 ... C1-pakketten die naar de STM gaan. Verwerkte bus-pakketten toont de pakketten die de parser verwerkt heeft, in dezelfde vorm als de Node-RED-logregels. De state geeft het laatste pakket. Het attribuut `pakketten` bevat de laatste twintig regels als lijst, en het attribuut `tekst` geeft dezelfde regels als gewone tekst met regeleinden.

## Adresmapping

De parser noemt de adressen 00 tot en met 1F de ingangsmodules (IMD) en 40 tot en met 5F de uitgangsmodules (AMD en JRM). Het PHC-nummer is de onderste vijf bits van het adres, dus de DIP-instelling. Een ingang met nummer n heeft bus-adres 0x00 + n, en een relais of rolluik met nummer n heeft bus-adres 0x40 + n. Relais en rolluik delen dat bereik, dus één nummer kan maar één uitgangsmodule zijn. De integratie controleert dat bij het toevoegen. De entity-id's houden het nummer, bijvoorbeeld `switch.peha_amd_00_kanaal0`.

## Entiteiten per module

Een relaismodule heeft acht schakelaars, een statussensor met acht tekens waarin de positie het kanaal aangeeft, de knop Status opvragen en de sensor Laatste bus-data.

Een rolluikmodule heeft vier covers, vier schuifregelaars Looptijd (3 tot 180 seconden, standaard 20, 25, 30 en 16), per kanaal een sensor Kanaal N status en twee vaste knoppen Kanaal N omhoog en Kanaal N omlaag. Daarnaast de statussensor, de knop Status opvragen en de sensor Laatste bus-data.

Een ingangsmodule heeft zestien binaire sensoren, een statussensor in de vorm `ingangen,LEDs`, de knop Status opvragen en de sensor Laatste bus-data. Na elke ingangsactie vraagt de integratie de status van de module automatisch opnieuw op, omdat een korte impuls anders geen uit-melding oplevert.

Een virtuele knop heeft een ingangsmodule, een kanaal en een functie: Aan > 0 seconden, Uit < 1 seconden, Aan > 1 seconden, Uit > 1 seconden of Aan > 2 seconden. Een klik stuurt één commando, zoals de Node-RED IMD GENERATOR. Er is geen loslaatcommando.

## Rolluiken

De cover staat in rust op onbekend, zodat de knoppen altijd aan staan. Tijdens een beweging staat hij op opening of closing. De echte status staat in het attribuut `status` van de cover en in de sensor Kanaal N status: open, closed, halted, opening, closing of unknown. Een stop tijdens een beweging geeft halted, omdat Home Assistant geen halted-status voor covers kent. De vaste knoppen Omhoog en Omlaag blijven altijd bruikbaar, ook tijdens een beweging.

Een commando gaat altijd naar de module, ook tijdens een beweging. Komt er geen eindmelding, dan sluit een vangnet de beweging af na de looptijd plus vijf seconden. Na een herstart herstelt de integratie de laatst bekende status uit de sensor.

## Events en services

Bij elke ingangsactie vuurt de integratie het event `peha_phc_ingang` af, met de velden module, adres, naam, kanaal en actie. De service `peha_phc.stuur_commando` stuurt een ruw commando, handig om te testen. De service `peha_phc.virtuele_ingang` stuurt een virtuele functie naar een ingangsmodule.

## Punten om op de hardware te controleren

De logregels zijn gecontroleerd tegen de voorbeelden uit de Node-RED-flow, maar de werkelijke modules moeten dat nog bevestigen. De interpretatie van de timer-events is een aanname: Timer afgelopen wordt gelezen als het einde van de beweging in de laatst gekozen richting. Test dat met een rolluik dat u kort laat lopen. De vangnetmarge staat in `TIMER_MARGE` in `const.py`.

## Tests

De protocollogica en de statusovergangen zijn te testen zonder Home Assistant. Vanuit de map van de repository start u dat met `python3 -m unittest discover -s tests -v`.
