"""Controles voor het protocol en de modulelogica (zonder Home Assistant).

Uitvoeren vanuit de map van de integratie:
    python3 -m unittest discover -s tests -v
"""
from __future__ import annotations

import pathlib
import sys
import types
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
COMPONENT = ROOT / "custom_components" / "peha_phc"

# Laad het pakket zonder __init__.py uit te voeren (die importeert Home Assistant).
_pkg = types.ModuleType("peha_phc")
_pkg.__path__ = [str(COMPONENT)]
sys.modules["peha_phc"] = _pkg

from peha_phc import protocol as p  # noqa: E402
from peha_phc.const import MODULE_INGANG, MODULE_RELAIS, MODULE_ROLLUIK  # noqa: E402
from peha_phc.models import CoverState, PhcModule  # noqa: E402


def _unwrap(frame: bytes) -> bytes:
    """Haalt C0/C1 en de escaping weg."""
    assert frame[0] == 0xC0 and frame[-1] == 0xC1
    out, escaped = bytearray(), False
    for byte in frame[1:-1]:
        if escaped:
            out.append({0xE0: 0xC0, 0xE1: 0xC1, 0x5D: 0x7D}[byte])
            escaped = False
        elif byte == 0x7D:
            escaped = True
        else:
            out.append(byte)
    return bytes(out)


def _bus(address: int, payload: list[int]) -> bytes:
    """Bouwt een busframe zoals een module het zou versturen (zonder toggle-bit)."""
    body = bytes([address, len(payload)]) + bytes(payload)
    crc = p.phc_crc(body)
    return body + bytes([crc & 0xFF, crc >> 8])


def _msg(address: int, payload: list[int]) -> p.Decoded:
    (frame,) = p.BusParser().feed(_bus(address, payload))
    return p.decode_frame(frame)


class CrcTests(unittest.TestCase):
    def test_voorbeelden_uit_flow_en_notities(self):
        self.assertEqual(p.phc_crc([0xFE, 0x00, 0x06, 0x00, 0x00, 0x01, 0x01]), 0xAEC9)
        self.assertEqual(p.phc_crc([0x43, 0x82, 0x05, 0x00]), 0x0848)
        self.assertEqual(p.phc_crc([0x43, 0x81, 0x02]), 0x99D8)
        self.assertEqual(p.phc_crc([0x01, 0x01, 0xF2]), 0x5155)


class FrameTests(unittest.TestCase):
    def test_statusopvraag_imd0_exact(self):
        expected = bytes.fromhex("C0 FE 00 06 00 00 01 01 C9 AE C1")
        self.assertEqual(p.status_frame(0x00), expected)

    def test_escaping_van_c0_in_payload(self):
        frame = p.command_frame(0x40, bytes([0xC0]))
        self.assertNotIn(0xC0, frame[1:-1])
        self.assertEqual(_unwrap(frame)[:7], bytes([0xFE, 0x00, 0x06, 0x00, 0x40, 0x01, 0xC0]))

    def test_rolluik_omlaag_30_seconden(self):
        body = _unwrap(p.cover_frame(0x42, 0, "omlaag", 300))
        self.assertEqual(body[4:10], bytes([0x42, 0x04, 0x06, 0x07, 0x2C, 0x01]))
        self.assertEqual(p.phc_crc(body[:-2]), body[-2] | (body[-1] << 8))

    def test_virtuele_ingang_header(self):
        body = _unwrap(p.virtual_input_frame(0x01, (15 << 4) | 2))
        self.assertEqual(body[:6], bytes([0xFE, 0x00, 0x21, 0x00, 0x01, 0xF2]))


class ParserTests(unittest.TestCase):
    def test_jrm_klaar_omlaag(self):
        (frame,) = p.BusParser().feed(bytes.fromhex("43 82 05 00 48 08"))
        msg = p.decode_frame(frame)
        self.assertEqual((msg.kind, msg.channel, msg.code), ("jrm_event", 0, 5))

    def test_jrm_stop_echo(self):
        (frame,) = p.BusParser().feed(bytes.fromhex("43 81 02 D8 99"))
        msg = p.decode_frame(frame)
        self.assertEqual((msg.kind, msg.channel, msg.code), ("output_cmd", 0, 2))

    def test_imd_event_knop_15_kort(self):
        (frame,) = p.BusParser().feed(bytes.fromhex("01 01 F2 55 51"))
        msg = p.decode_frame(frame)
        self.assertEqual((msg.kind, msg.channel, msg.action, msg.pressed),
                         ("input_event", 15, "kort_ingedrukt", True))

    def test_ruis_en_gesplitste_bytes(self):
        parser = p.BusParser()
        frames = parser.feed(bytes.fromhex("00 00 43 82"))
        frames += parser.feed(bytes.fromhex("05 00 48 08 01 01 F2"))
        frames += parser.feed(bytes.fromhex("55 51"))
        self.assertEqual([f.address for f in frames], [0x43, 0x01])


class ModelTests(unittest.TestCase):
    def test_relais_status_bit6_is_index6(self):
        module = PhcModule(kind=MODULE_RELAIS, phc=0, name="relais", address=0x40)
        module.apply(_msg(0x40, [0x01, 0x40]))
        self.assertEqual(module.status_text(), "00000010")

    def test_rolluik_omlaag_en_klaar(self):
        module = PhcModule(kind=MODULE_ROLLUIK, phc=2, name="rolluik", address=0x42)
        module.apply(_msg(0x42, [0x06, 0x07, 0x2C, 0x01]))
        self.assertEqual(module.covers[0].status, "closing")
        self.assertEqual(module.covers[0].duration, 30.0)
        module.apply(_msg(0x42, [0x05, 0x00]))
        self.assertEqual(module.covers[0].status, "closed")

    def test_rolluik_stop_geeft_halted(self):
        module = PhcModule(kind=MODULE_ROLLUIK, phc=2, name="rolluik", address=0x42)
        module.apply(_msg(0x42, [0x05, 0x07, 0x2C, 0x01]))
        self.assertEqual(module.covers[0].status, "opening")
        module.apply(_msg(0x42, [0x02]))
        self.assertEqual(module.covers[0].status, "halted")
        self.assertIs(module.covers[0].closed, False)

    def test_ingang_status_en_event(self):
        module = PhcModule(kind=MODULE_INGANG, phc=1, name="ingang", address=0x01)
        module.apply(_msg(0x01, [0x01, 0x00, 0x05, 0x00]))
        self.assertEqual(module.inputs[0], True)
        self.assertEqual(module.inputs[1], False)
        self.assertEqual(module.inputs[2], True)
        effects = module.apply(_msg(0x01, [0xF2]))
        self.assertEqual(module.inputs[15], True)
        self.assertEqual(effects, [("input", 15, "kort_ingedrukt")])


class RegressionTests(unittest.TestCase):
    def test_ingang_status_zonder_leds_toont_vraagtekens(self):
        module = PhcModule(kind=MODULE_INGANG, phc=1, name="ingang", address=0x01)
        module.apply(_msg(0x01, [0xF2]))
        self.assertEqual(module.status_text(), "?" * 15 + "1," + "?" * 16)

    def test_standaard_looptijden_per_kanaal(self):
        module = PhcModule(kind=MODULE_ROLLUIK, phc=2, name="rolluik", address=0x42)
        self.assertEqual(module.runtimes, [20.0, 25.0, 30.0, 16.0])

    def test_nieuwe_beweging_verhoogt_generatie(self):
        cover = CoverState()
        cover.start("omlaag", 20.0)
        eerste = cover.generation
        cover.start("omhoog")
        self.assertGreater(cover.generation, eerste)
        self.assertEqual(cover.duration, 0.0)

    def test_ruis_blijft_begrensd_en_geldig_frame_wordt_nog_gevonden(self):
        parser = p.BusParser()
        parser.feed(bytes([0x55]) * 300)
        self.assertLessEqual(len(parser._buf), 131)
        frames = parser.feed(bytes.fromhex("43 82 05 00 48 08"))
        self.assertEqual([f.address for f in frames], [0x43])


if __name__ == "__main__":
    unittest.main()
