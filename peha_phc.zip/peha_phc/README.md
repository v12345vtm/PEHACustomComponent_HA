# Peha PHC voor Home Assistant

Deze custom integratie vervangt de Node-RED-flow. Commando's gaan via de STM-stuureenheid (USB-kabel, met C0/C1-framing en escaping). Alles wat op de bus gebeurt, komt binnen via de busdongle als ruwe RS485-data en gaat door de parser in de integratie.

## Installatie

Verwijder eerst een eventuele eerdere versie van Peha PHC in Home Assistant, via Instellingen, Apparaten en diensten, Peha PHC, Verwijderen. Oude apparaten en entiteiten kunnen anders botsen met deze versie. Kopieer daarna de map `custom_components/peha_phc` naar de map `custom_components` van Home Assistant. Stop Node-RED zolang de poorten nog door Node-RED gebruikt worden, want twee programma's die tegelijk van dezelfde poort lezen, halen elkaars data weg.

Herstart Home Assistant en voeg de integratie toe via Integratie toevoegen, Peha PHC. De standaardpoorten zijn `/dev/ttyACM0` voor de USB-kabel en `/dev/ttyUSB0` voor de busdongle. Modules voeg je later toe via Configureren. Daarbij vul je alleen het PHC-nummer en een naam in.

## Adresmapping

De flow zelf laat de mapping al zien. De parser noemt de adressen 00 tot en met 1F de ingangsmodules (IMD) en 40 tot en met 5F de uitgangsmodules (AMD en JRM). Het PHC-nummer is de onderste vijf bits van het adres, `addr & 0x1F`, en dat is dezelfde waarde als de DIP-instelling. Een ingang met nummer n heeft bus-adres 0x00 + n, en een relais of rolluik met nummer n heeft bus-adres 0x40 + n. Relais en rolluik delen dat bereik, dus één nummer kan maar één uitgangsmodule zijn. De integratie controleert dat bij het toevoegen.

## Entiteiten

Een relaismodule krijgt acht schakelaars (kanaal 0 tot en met 7), een sensor Status met acht tekens waarbij de positie het kanaal aangeeft (`00000000`), een knop Status opvragen en een diagnostische sensor Laatste bus-data.

Een rolluikmodule krijgt vier covers (kanaal 0 tot en met 3) met open, dicht en stop. Per kanaal is er een schuifregelaar Looptijd van 3 tot 180 seconden, met als standaard 20, 25, 30 en 16 seconden voor de kanalen 0 tot en met 3. Daarnaast zijn er per kanaal twee knoppen, Omhoog en Omlaag, die altijd een commando sturen, ook als de cover al als dicht of open gemeld staat. Verder komen er een sensor Status per kanaal, de knop Status opvragen en de sensor Laatste bus-data.

Een ingangsmodule krijgt zestien binaire sensoren (ingang 0 tot en met 15), een sensor Status in de vorm `ingangen,LEDs` waarbij elk deel uit zestien tekens bestaat, de knop Status opvragen en de sensor Laatste bus-data.

Een virtuele knop krijgt een ingangsmodule, een kanaal en een functie (kort, lang of extra lang). Bij een klik stuurt de integratie het indrukcommando, wacht een korte tijd en stuurt daarna het loslaatcommando.

De entity-id's behouden het nummer, bijvoorbeeld `switch.peha_amd_00_kanaal0`.

## Rolluiken

Een commando gaat altijd naar de module, ook tijdens een beweging, zodat je altijd kunt ingrijpen als de looptijd niet klopt. De status komt uit de feedback van de module en niet uit het commando zelf. Bij omlaag staat de cover eerst op closing en daarna, na de melding klaar of timer afgelopen, op closed. Bij omhoog is dat opening en daarna open.

Een stop tijdens een beweging zet de cover op open met het attribuut status halted, omdat Home Assistant geen halted-status voor covers kent. Komt er helemaal geen eindmelding, dan sluit een vangnet de beweging af na de looptijd plus vijf seconden.

Na een herstart van Home Assistant herstelt de integratie de laatst bekende positie uit de opgeslagen status, want de module meldt zijn positie zelf niet.

## Events en services

Bij elke ingangsactie vuurt de integratie het event `peha_phc_ingang` af, met de velden module, adres, naam, kanaal en actie. De actie is bijvoorbeeld `kort_ingedrukt`, `lang_ingedrukt` of `losgelaten`. Met de service `peha_phc.stuur_commando` stuur je een ruw commando, wat handig is om te testen. Met de service `peha_phc.virtuele_ingang` simuleer je een klik op een ingang.

## Punten om op de hardware te controleren

De wachttijden van de virtuele knop (0,2 seconde voor kort, 1,5 seconde voor lang en 2,5 seconde voor extra lang) zijn schattingen. Ze staan in `const.py`, net als de vangnetmarge `TIMER_MARGE`. De interpretatie van de timer-events is ook een aanname: Timer afgelopen wordt gelezen als het einde van de beweging in de laatst gekozen richting. Test dat met een rolluik dat je kort laat lopen.

## Tests

De protocollogica en de statusovergangen zijn te testen zonder Home Assistant. Vanuit de map `peha_phc` start je dat met `python3 -m unittest discover -s tests -v`.
