# CHANGELOG - Peha PHC

## 0.1.2

- Ingangen: de statusopvraag komt nu pas na het loslaten van de knop, na 1,5 seconde. Tijdens het indrukken vraagt de integratie niets meer. Daardoor blijft een ingang na een lange druk niet meer op "hoog" staan.
- Komt er geen loslaat-event, dan vraagt de integratie na 10 seconden alsnog de status op.
- Een verouderd antwoord op een statusopvraag wordt rechtgezet door de statusopvraag na het loslaten.
- De service `peha_phc.virtuele_ingang` accepteert ook de naam en het nummer van de functie, net als de Node-RED-flow: `aan > 0 seconden` of `2`.
- Versie 0.1.2 in alle bestanden en op de apparaten. De README's (Nederlands en Engels) zijn bijgewerkt.

## 0.1.1

- Twee poortschakelaars op het hub-apparaat: Poort USB-kabel (STM) en Poort busdongle (RS485). Ze staan standaard aan. Uit sluit de poort echt, zodat een ander programma hem kan gebruiken. De stand blijft bewaard na een herstart.
- Sensor "Verstuurde pakketten (USB-kabel)": de C0 ... C1-pakketten die naar de STM gaan, met de betekenis erbij.
- Sensor "Verwerkte bus-pakketten": de pakketten die de parser verwerkt heeft, in dezelfde vorm als de Node-RED-logregels.
- Na een ingangsevent vraagt de integratie automatisch de status van die module opnieuw op.
- Rolluiken: de cover staat in rust op onbekend, zodat de knoppen altijd aan staan. Tijdens een beweging staat hij op opening of closing. De echte status staat in het attribuut `status` en in de nieuwe sensor "Kanaal N status". Die status wordt na een herstart hersteld.
- Virtuele knoppen hebben vijf functies: Aan > 0 seconden, Uit < 1 seconden, Aan > 1 seconden, Uit > 1 seconden en Aan > 2 seconden. Een klik stuurt één commando, zonder loslaatcommando. In 0.1.0 stuurde een klik nog een indruk en een loslaatcommando.
- Het versienummer staat in alle bestanden en op de apparaten in Home Assistant.
- De repository-links staan in het manifest en in de README.

## 0.1.0

- Eerste versie: configuratie via de gebruikersinterface, relais (8 schakelaars), rolluiken (4 covers met een looptijd per kanaal), ingangen (16 binaire sensoren), statussensoren, Status opvragen en virtuele knoppen.
