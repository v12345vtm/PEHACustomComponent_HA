# Peha PHC voor Home Assistant

Versie 1.1.0. Een Home Assistant-integratie voor een Peha PHC-installatie. De commando's gaan via
de usbkabel naar de STM-stuureenheid. De stand komt binnen via een USB-dongle op de RS485-databus.

## Wat je krijgt

| Module | Entiteiten |
|---|---|
| **Relais** (8 kanalen) | Per kanaal een schakelaar. Aan en uit sturen, en de stand toont wat de bus meldt. Een statussensor en een knop *Status opvragen*. |
| **Rolluik** (4 kanalen) | Per kanaal een cover met omhoog, stop en omlaag. Een looptijd per kanaal. Een statussensor met de laatste terugmelding van de module, en een knop *Status opvragen*. |
| **Ingangen** (16 ingangen) | Per ingang een binary sensor (aan = de knop is actief). Per ingang ook een LED-sensor, die standaard uit staat. Een statussensor en een knop *Status opvragen*. Elke wijziging vuurt het event `peha_ingang`. |

Per installatie komen er bij: twee verbindingssensoren (bus en usbkabel), een knop *Status alle
modules opvragen*, en drie diagnostische tekstsensoren (laatste busbericht, laatste STM-commando en
laatste STM-antwoord).

## Installeren

1. Kopieer de map `custom_components/peha` naar `config/custom_components/peha`.
2. Herstart Home Assistant volledig.
3. Ga naar *Instellingen → Apparaten en diensten → Integratie toevoegen* en zoek op **Peha PHC**.

De integratie vraagt om twee poorten. De standaardwaarden zijn:

- **Usbkabel naar de STM** (commando's): `/dev/ttyACM0`
- **Bus-dongle op de RS485-databus** (terugmeldingen): `/dev/ttyUSB0`

Gebruik bij voorkeur de vaste namen onder `/dev/serial/by-id/`. Die veranderen niet als je de stekkers
in een andere volgorde insteekt. Heb je geen hardware? Zet dan de **testmodus** aan.

## Modules toevoegen

Klik op de integratie en daarna op **Configureren**. Je ziet drie toevoegingen:

- **Relais toevoegen**
- **Rolluik toevoegen**
- **Ingangen toevoegen**

Bij elk vul je alleen het **PHC-nummer** (0 t/m 31) en een **naam** in. Het aantal kanalen is vast.
Het PHC-nummer rekent de integratie om naar het adres op de bus:

| Type | PHC-nummer | Adres op de bus |
|---|---|---|
| Relais | 0 | `0x40` |
| Rolluik | 2 | `0x42` |
| Ingangen | 0 | `0x00` |

Relais en rolluik delen het bereik `0x40` t/m `0x5F`. Een nummer kun je dus maar één keer gebruiken
binnen dat bereik. De integratie controleert dat.

**Looptijden van een rolluik** stel je apart in via *Looptijden rolluik instellen*. Kies het rolluik en
vul per kanaal de tijd in seconden in. Elk kanaal mag een andere tijd hebben. Bij 0 loopt het rolluik
tot je stop geeft.

## Statussensor per module

Elke module heeft een sensor *Status*. Die toont de stand zoals de bus die meldt:

| Module | Voorbeeld van de waarde | Betekenis |
|---|---|---|
| Relais | `10010000` | Kanaal 0 en 3 staan aan. Kanaal 0 is het eerste teken. |
| Ingangen | `0000000000000000,0000000000000000` | Eerst de 16 ingangen, daarna de 16 LED's. |
| Rolluik | `kanaal 2: omlaag gegaan` | De laatste terugmelding van de JRM, nadat hij een opdracht heeft uitgevoerd. |

Een `?` betekent dat die waarde nog niet bekend is. Voordat de module iets heeft gemeld, is de sensor
*onbekend*. Druk op *Status opvragen* om de stand direct op te vragen.

Het aantal LED's is standaard 16, ook als de module er maar 8 heeft. De extra LED-sensoren staan
uit. De stand van alle LED's staat al in de statussensor.

## Rolluiken

De integratie weet niet waar het rolluik precies staat. De module meldt alleen wat hij doet: hij is
gestart, of hij is gestopt, of een timer is afgelopen. Daarom toont de cover nooit *open* of *dicht*.
Dat zou de knop in Home Assistant uitschakelen. De cover toont alleen *aan het openen*, *aan het
sluiten* of *onbekend*.

Gevolgen:

- **Een tweede druk op omlaag (of omhoog) stuurt altijd het commando.** Ook als het rolluik nog beweegt,
  of als de looptijd al voorbij is. Zo kun je zelf bijsturen als de looptijd niet klopt.
- Met een looptijd stuurt de integratie die tijd mee naar de module. De module stopt dan zelf na die tijd.
- Stop je het rolluik op een andere manier (bijvoorbeeld met de wandschakelaar) en meldt de module dat
  niet, dan blijft de cover op *aan het sluiten* staan tot je stop drukt. Alleen de weergave blijft
  dan achter. Commando's blijven werken.

## Services

Alle services staan onder *Ontwikkelaarstools → Acties*, bij `peha`. Heb je meer dan één installatie,
geef dan het veld `hub` mee met de naam.

| Service | Velden | Werking |
|---|---|---|
| `peha.relais_commando` | `module`, `kanaal`, `actie`, `tijd` | Stuurt één relaiskanaal, ook de timer- en vertraagde acties. |
| `peha.rolluik_beweeg` | `module`, `kanaal`, `actie`, `tijd`, `prioriteit` | Beweegt een rolluik. Met `tijd` gebruik je een andere looptijd dan ingesteld. |
| `peha.status_opvragen` | `module`, `type` (optioneel) | Vraagt de stand op bij één of alle modules. |
| `peha.stuur_commando` | `adres`, `payload` (hex) | Stuurt een zelf samengesteld commando. Voor experimenten. |
| `peha.simuleer_busbericht` | `adres`, `payload` (hex) | Verwerkt een busbericht alsof het van de bus kwam. |

Voorbeeld: rolluik 2, kanaal 1, 5 seconden omhoog:

```yaml
action: peha.rolluik_beweeg
data:
  module: 2
  kanaal: 1
  actie: omhoog
  tijd: 5
```

Een ingang "indrukken" in de testmodus: adres `00`, payload `01 00 01 00`.

## Event bij een ingang

```yaml
trigger:
  - platform: event
    event_type: peha_ingang
    event_data:
      adres: 0
      ingang: 0
      actief: true
```

## Testen zonder hardware

Met de testmodus gaat er niets naar de poorten. Een commando krijgt een nagebootst antwoord van de bus.
Zo kun je schakelaars, rolluiken en statussensoren uitproberen.

## Hoe het werkt

**Twee poorten, twee protocollen.** De commando's gaan naar de STM in C0/C1-frames. Daarbij gelden
dezelfde escape-regels als in je Node-RED-flow (`7D E0` voor C0, `7D E1` voor C1, `7D 5D` voor 7D).
De CRC rekent mee over de STM-kop `FE 00 06 00`, net als in de flow. De bus-dongle leest ruwe PHC-frames
zonder C0/C1: adres, lengte, payload en een CRC-16. De parser zoekt die frames in de stroom, ook als er
ruis tussen zit.

**De stand.** Een antwoord van een relais (`00 xx` of `01 xx`) zet alle acht kanalen. Een ingangsmodule
meldt zijn ingangen en LED's. Een rolluik meldt een gebeurtenis per kanaal. De hub bewaart dat, en de
entiteiten lezen het daaruit.

## Aannames om te controleren

- **Rolluik-terugmeldingen (codes 03 t/m 08)** komen uit de commentaar in je flow. De handleiding (PDF)
  zat niet in de upload, dus dat is niet nagekeken. Klopt de betekenis niet, pas dan `ROLLUIK_GEBEURTENIS`
  in `protocol.py` aan.
- **Start omhoog** staat niet in de flow. Komt die terugmelding toch, dan zie je hem als *onbekend
  bericht* in de sensor *Laatste busbericht*.
- **Ingangen:** een bit op 1 betekent "actief". Klopt dat niet, draai het om in `hub.py`.
- **Commando's naar de STM** worden in één keer geschreven. In je flow staat de uitvoermodus op
  `interbyte`. Werkt een commando niet, controleer dan of de STM een pauze tussen de bytes nodig heeft.

## Tests

De tests draaien zonder Home Assistant:

```bash
cd tests
python3 -m unittest discover -p "test_*.py" -v
```

- `test_protocol.py`: CRC, de frames uit je flow, de parser (ook met ruis) en de decoders.
- `test_hub.py`: commando's, busberichten, rolluiken met noodstop en de volledige testmodus.
- `test_vs_flow.py`: vergelijkt de encoder met de bouwfuncties uit je Node-RED-flow (`flow_referentie.js`).
  Dit vereist Node.js en wordt overgeslagen als het ontbreekt.

## Structuur

```
README.md
custom_components/peha/
├── __init__.py         services, opzetten en afsluiten van de installatie
├── manifest.json
├── const.py            constanten
├── model.py            modules, kanalen en het PHC-nummer → adres
├── protocol.py         CRC, STM-frames (C0/C1), busparser, decoders
├── transport.py        seriële poorten (usbkabel en bus) en de testmodus
├── hub.py              stand per module, commando's, busberichten verwerken
├── entity.py           basis voor alle entiteiten
├── config_flow.py      installatie en opties
├── switch.py           relaiskanalen
├── cover.py            rolluikkanalen
├── binary_sensor.py    ingangen, LED's, verbinding
├── button.py           status opvragen
├── sensor.py           statussensor per module, diagnostische tekst
├── services.yaml
└── translations/nl.json
tests/
├── test_protocol.py, test_hub.py, test_vs_flow.py
└── flow_referentie.js  kopie van de bouwfuncties uit de flow, als referentie
```
