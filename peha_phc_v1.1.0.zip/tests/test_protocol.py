import unittest

import _laad  # noqa: F401  (zet het pad goed)
from custom_components.peha import protocol as p
from custom_components.peha.model import Module, module_adres


def hexs(data: bytes) -> str:
    return " ".join(f"{b:02X}" for b in data)


class CrcTest(unittest.TestCase):
    def test_standaard_testwaarde(self):
        self.assertEqual(p.crc16(b"123456789"), 0x906E)

    def test_echte_frames_uit_de_flow(self):
        # Commentaar in de flow ("pakketten analyser parser"):
        # 40 01 01 EB C8 is een statusverzoek naar 0x40, 40 02 01 00 09 46 is het antwoord.
        a = bytes.fromhex("40 01 01 EB C8")
        b = bytes.fromhex("40 02 01 00 09 46")
        self.assertEqual(p.bus_frame(0x40, b"\x01"), a)
        self.assertEqual(p.bus_frame(0x40, b"\x01\x00"), b)


class StmFrameTest(unittest.TestCase):
    # Vectoren gegenereerd met de bouwfuncties uit de flow (zie flow_referentie.js)
    def test_vectoren_uit_de_flow(self):
        self.assertEqual(hexs(p.stm_frame(0x40, p.relais_payload(0, "status"))),
                         "C0 FE 00 06 00 40 01 01 BF A8 C1")
        self.assertEqual(hexs(p.stm_frame(0x40, p.relais_payload(0, "aan"))),
                         "C0 FE 00 06 00 40 01 02 24 9A C1")
        self.assertEqual(hexs(p.stm_frame(0x40, p.relais_payload(0, "aan_vertraagd", 192))),
                         "C0 FE 00 06 00 40 03 08 7D E0 00 61 F0 C1")
        self.assertEqual(hexs(p.stm_frame(0x7D, p.relais_payload(0, "omschakelen_met_timer", 600))),
                         "C0 FE 00 06 00 7D 5D 03 0D 58 02 F6 95 C1")
        self.assertEqual(hexs(p.stm_frame(0x42, p.rolluik_payload(1, "omhoog", 2.5, 7))),
                         "C0 FE 00 06 00 42 04 25 07 19 00 47 7A C1")
        self.assertEqual(hexs(p.stm_frame(0x02, p.STATUS_VERZOEK)),
                         "C0 FE 00 06 00 02 01 01 71 1B C1")

    def test_ontescape_is_het_omgekeerde(self):
        frame = p.stm_frame(0x7D, bytes([0xC0, 0xC1, 0x7D]))
        self.assertEqual(p.ontescape(frame)[:4], p.STM_KOP)
        self.assertNotIn(0xC0, frame[1:-1])
        self.assertNotIn(0xC1, frame[1:-1])


class PayloadTest(unittest.TestCase):
    def test_relais_kanaal_in_bovenste_bits(self):
        self.assertEqual(p.relais_payload(7, "aan"), bytes([0xE2]))
        self.assertEqual(p.relais_payload(7, "aan_met_timer", 5), bytes([0xEA, 0x05, 0x00]))

    def test_rolluik_tijd_in_tienden(self):
        self.assertEqual(p.rolluik_payload(1, "omhoog", 5), bytes([0x25, 0x07, 0x32, 0x00]))
        self.assertEqual(p.rolluik_payload(2, "stop"), bytes([0x42]))

    def test_ongeldige_invoer(self):
        with self.assertRaises(ValueError):
            p.relais_payload(8, "aan")
        with self.assertRaises(ValueError):
            p.relais_payload(0, "aan_met_timer")  # tijd ontbreekt
        with self.assertRaises(ValueError):
            p.rolluik_payload(4, "omhoog")
        with self.assertRaises(ValueError):
            p.stm_frame(0x100, b"\x01")


class ParserTest(unittest.TestCase):
    def setUp(self):
        self.a = bytes.fromhex("40 01 01 EB C8")
        self.b = bytes.fromhex("40 02 01 00 09 46")
        self.relais = p.bus_frame(0x40, bytes([0x01, 0x05]))

    def test_meerdere_frames_in_een_keer(self):
        frames = p.BusParser().feed(self.a + self.b + self.relais)
        self.assertEqual([f.raw for f in frames], [self.a, self.b, self.relais])

    def test_byte_voor_byte(self):
        parser, gevonden = p.BusParser(), []
        stroom = self.a + self.b + self.relais
        for i in range(len(stroom)):
            gevonden += parser.feed(stroom[i:i + 1])
        self.assertEqual([f.raw for f in gevonden], [self.a, self.b, self.relais])

    def test_ruis_met_grote_lengte_blokkeert_niet(self):
        kwaad = bytes([0x40, 0x7F, 0x11]) + self.a + self.b
        frames = p.BusParser().feed(kwaad)
        self.assertEqual([f.raw for f in frames], [self.a, self.b])


class DecoderTest(unittest.TestCase):
    def test_relais(self):
        self.assertEqual(p.relais_status(bytes([0x01, 0x05])), 5)
        self.assertEqual(p.relais_status(bytes([0x00, 0x80])), 0x80)
        self.assertIsNone(p.relais_status(bytes([0x02])))  # een commando-echo telt niet als stand

    def test_ingang(self):
        self.assertEqual(p.ingang_status(bytes([0x01, 0x00, 0x05, 0x00])), (5, 0, 8))
        self.assertEqual(p.ingang_status(bytes([0x01, 0x01, 0x00, 0x80, 0x02])), (0x8000, 0x0201, 16))
        self.assertIsNone(p.ingang_status(bytes([0x01, 0x00])))

    def test_rolluik(self):
        self.assertEqual(p.rolluik_gebeurtenis(bytes([0x23, 0x00])), (1, "start_omlaag"))
        self.assertEqual(p.rolluik_gebeurtenis(bytes([0x05, 0x00])), (0, "klaar_omlaag"))
        self.assertIsNone(p.rolluik_gebeurtenis(bytes([0x01, 0x05])))


class AdresTest(unittest.TestCase):
    def test_mapping_uit_de_flow(self):
        self.assertEqual(module_adres("relais", 0), 0x40)
        self.assertEqual(module_adres("rolluik", 2), 0x42)
        self.assertEqual(module_adres("ingang", 0), 0x00)
        self.assertEqual(module_adres("ingang", 2), 0x02)

    def test_buiten_bereik(self):
        with self.assertRaises(ValueError):
            module_adres("relais", 32)
        self.assertEqual(Module.van_dict({"type": "rolluik", "nummer": "3"}).adres, 0x43)


if __name__ == "__main__":
    unittest.main()
