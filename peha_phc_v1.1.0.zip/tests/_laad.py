"""Laadt het pakket zonder de __init__ (die Home Assistant importeert). Zo draaien de tests zonder HA."""
import pathlib
import sys
import types

ROOT = pathlib.Path(__file__).resolve().parents[1] / "custom_components"
if "custom_components" not in sys.modules:
    pkg = types.ModuleType("custom_components")
    pkg.__path__ = [str(ROOT)]
    sys.modules["custom_components"] = pkg
    sub = types.ModuleType("custom_components.peha")
    sub.__path__ = [str(ROOT / "peha")]
    sys.modules["custom_components.peha"] = sub
