import asyncio
import unittest

import _laad  # noqa: F401
from custom_components.peha import protocol as p
from custom_components.peha.hub import PehaError, PehaHub
from custom_components.peha.model import Module
from custom_components.peha.transport import DemoTransport


class FakeStm:
    """Vangt de geschreven STM-frames op. Doet verder niets."""

    is_open = True

    def __init__(self):
        self.geschreven = []

    async def open(self):
        return None

    async def close(self):
        return None

    async def write(self, data):
        self.geschreven.append(data)

    async def read(self):
        await asyncio.Event().wait()


def maak_hub(modules, **kw):
    events, updates = [], []

    def notify(soort, data):
        if soort == "event":
            events.append(data)
        elif soort == "module":
            updates.append(data)

    stm = FakeStm()
    hub = PehaHub("test", modules, stm, stm, notify, stm_pauze=0, **kw)
    hub.stm_ok = True
    return hub, stm, events, updates


RELAIS = Module("relais", 0)
ROLLUIK = Module("rolluik", 2, looptijden=(20.0, 25.0, 30.0, 16.0))
INGANG = Module("ingang", 0)


class RelaisTest(unittest.IsolatedAsyncioTestCase):
    async def test_commando_stuurt_frame_en_zet_stand(self):
        hub, stm, _, updates = maak_hub([RELAIS])
        await hub.relais_commando(0x40, 3, "aan")
        self.assertEqual(stm.geschreven, [p.stm_frame(0x40, bytes([0x62]))])
        self.assertIs(hub.state[0x40]["kanalen"][3], True)
        self.assertIn(0x40, updates)

    async def test_omschakelen_wisselt_bekende_stand(self):
        hub, _, _, _ = maak_hub([RELAIS])
        hub.state[0x40]["kanalen"][0] = True
        await hub.relais_commando(0x40, 0, "omschakelen")
        self.assertIs(hub.state[0x40]["kanalen"][0], False)

    async def test_status_komt_van_de_bus(self):
        hub, _, _, _ = maak_hub([RELAIS])
        hub.verwerk_busbytes(p.bus_frame(0x40, bytes([0x01, 0x05])))
        self.assertEqual(
            [hub.state[0x40]["kanalen"][k] for k in range(8)],
            [True, False, True, False, False, False, False, False],
        )
        self.assertIn("kanalen aan [0, 2]", hub.laatste_busregel)


class IngangTest(unittest.IsolatedAsyncioTestCase):
    async def test_events_bij_wijziging(self):
        hub, _, events, _ = maak_hub([INGANG])
        hub.verwerk_busbytes(p.bus_frame(0x00, bytes([0x01, 0x00, 0x00, 0x00])))  # eerste stand: geen event
        hub.verwerk_busbytes(p.bus_frame(0x00, bytes([0x01, 0x00, 0x01, 0x00])))  # ingang 0 aan
        hub.verwerk_busbytes(p.bus_frame(0x00, bytes([0x01, 0x00, 0x00, 0x00])))  # ingang 0 uit
        self.assertEqual([(e["ingang"], e["actief"]) for e in events], [(0, True), (0, False)])

    async def test_altijd_16_ingangen_en_16_leds(self):
        hub, _, _, _ = maak_hub([INGANG])
        hub.verwerk_busbytes(p.bus_frame(0x00, bytes([0x01, 0x01, 0x00, 0x80])))  # 8 LED's, ingang 15 aan
        stand = hub.state[0x00]
        self.assertEqual(len(stand["ingangen"]), 16)
        self.assertEqual(len(stand["leds"]), 16)
        self.assertIs(stand["ingangen"][15], True)
        self.assertIs(stand["leds"][0], True)


class RolluikTest(unittest.IsolatedAsyncioTestCase):
    async def test_terugmelding_zet_tekst_maar_geen_eindstand(self):
        hub, _, _, _ = maak_hub([ROLLUIK])
        hub.verwerk_busbytes(p.bus_frame(0x42, bytes([0x23, 0x00])))  # kanaal 1 start omlaag
        self.assertEqual(hub.state[0x42]["kanalen"][1]["beweging"], "omlaag")
        hub.verwerk_busbytes(p.bus_frame(0x42, bytes([0x05, 0x00])))  # kanaal 0 klaar omlaag
        kan0 = hub.state[0x42]["kanalen"][0]
        self.assertIsNone(kan0["beweging"])
        self.assertEqual(hub.state[0x42]["laatste"], "kanaal 0: omlaag gegaan")
        self.assertEqual(hub.state[0x42]["kanalen"][1]["beweging"], "omlaag")
        self.assertNotIn("gesloten", kan0)  # geen eindstand: die zou de knop in HA uitschakelen

    async def test_tweede_omlaag_wordt_altijd_verstuurd(self):
        hub, stm, _, _ = maak_hub([ROLLUIK])
        await hub.rolluik_commando(0x42, 0, "omlaag")
        await hub.rolluik_commando(0x42, 0, "omlaag")  # tweede druk terwijl het rolluik beweegt
        self.assertEqual(len(stm.geschreven), 2)

    async def test_optimistisch_en_noodstop_zonder_terugmelding(self):
        hub, _, _, _ = maak_hub([ROLLUIK], noodstop_marge=0.01)
        await hub.rolluik_commando(0x42, 0, "omhoog", tijd=0.02)
        self.assertEqual(hub.state[0x42]["kanalen"][0]["beweging"], "omhoog")
        await asyncio.sleep(0.1)
        self.assertIsNone(hub.state[0x42]["kanalen"][0]["beweging"])

    async def test_stop_annuleert_beweging(self):
        hub, stm, _, _ = maak_hub([ROLLUIK])
        await hub.rolluik_commando(0x42, 2, "omlaag")
        await hub.rolluik_commando(0x42, 2, "stop")
        self.assertIsNone(hub.state[0x42]["kanalen"][2]["beweging"])
        self.assertEqual(stm.geschreven[-1], p.stm_frame(0x42, bytes([0x42])))


class FoutenTest(unittest.IsolatedAsyncioTestCase):
    async def test_onbekend_adres_en_verkeerd_type(self):
        hub, _, _, _ = maak_hub([RELAIS])
        with self.assertRaises(PehaError):
            await hub.relais_commando(0x41, 0, "aan")
        with self.assertRaises(PehaError):
            await hub.rolluik_commando(0x40, 0, "stop")


class TestmodusTest(unittest.IsolatedAsyncioTestCase):
    async def test_rondgang(self):
        modules = [RELAIS, ROLLUIK, INGANG]
        demo = DemoTransport(modules)
        hub = PehaHub("demo", modules, demo, demo, lambda s, d: None, stm_pauze=0)
        await hub.start()
        try:
            await hub.relais_commando(0x40, 0, "aan")
            await asyncio.sleep(0.05)
            self.assertIs(hub.state[0x40]["kanalen"][0], True)

            await hub.vraag_status(0x40)
            await asyncio.sleep(0.05)
            self.assertIs(hub.state[0x40]["kanalen"][0], True)

            await hub.rolluik_commando(0x42, 0, "omlaag", tijd=0.05)
            await asyncio.sleep(0.01)
            self.assertEqual(hub.state[0x42]["kanalen"][0]["beweging"], "omlaag")
            await asyncio.sleep(0.15)
            self.assertIsNone(hub.state[0x42]["kanalen"][0]["beweging"])
            self.assertEqual(hub.state[0x42]["laatste"], "kanaal 0: omlaag gegaan")

            await hub.vraag_status(0x00)
            await asyncio.sleep(0.05)
            self.assertIs(hub.state[0x00]["ingangen"][0], False)
            self.assertTrue(hub.bus_ok and hub.stm_ok)
        finally:
            await hub.stop()


if __name__ == "__main__":
    unittest.main()
