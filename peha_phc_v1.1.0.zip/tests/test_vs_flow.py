"""Vergelijkt de Python-encoder met de bouwfuncties uit de Node-RED-flow (via flow_referentie.js).

Wordt overgeslagen als Node.js niet geïnstalleerd is.
"""
import json
import pathlib
import shutil
import subprocess
import unittest

import _laad  # noqa: F401
from custom_components.peha import protocol as p

HIER = pathlib.Path(__file__).resolve().parent


def hexs(data: bytes) -> str:
    return " ".join(f"{b:02X}" for b in data)


@unittest.skipUnless(shutil.which("node"), "Node.js niet geïnstalleerd")
class FlowVergelijkingTest(unittest.TestCase):
    def test_encoder_is_gelijk_aan_de_flow(self):
        cases, verwacht = [], []
        for adres in (0x40, 0x5F, 0x7D):
            for kanaal in (0, 7):
                for actie in p.RELAIS_CODES:
                    tijden = [1, 125, 192, 600] if actie in p.RELAIS_MET_TIJD else [None]
                    for tijd in tijden:
                        msg = {"adres": f"{adres:02x}", "kanaal": str(kanaal), "functie": actie}
                        if tijd is not None:
                            msg["tijd"] = tijd
                        cases.append({"fn": "amd", "msg": msg})
                        verwacht.append(hexs(p.stm_frame(adres, p.relais_payload(kanaal, actie, tijd))))
        for adres in (0x40, 0x42, 0x7D):
            for kanaal in (0, 3):
                for actie in p.ROLLUIK_CODES:
                    if actie == "status" and kanaal != 0:
                        continue
                    tijd = 2.5 if actie in p.ROLLUIK_MET_TIJD else None
                    msg = {"adres": f"{adres:02x}", "kanaal": str(kanaal), "functie": actie, "prioriteit": 7}
                    if tijd is not None:
                        msg["tijd"] = tijd
                    cases.append({"fn": "jrm", "msg": msg})
                    verwacht.append(hexs(p.stm_frame(adres, p.rolluik_payload(kanaal, actie, tijd or 0.0, 7))))
        for adres in (0, 1, 2, 31):
            cases.append({"fn": "imd", "msg": {"adres": f"{adres:02x}"}})
            verwacht.append(hexs(p.stm_frame(adres, p.STATUS_VERZOEK)))

        uit = subprocess.run(
            ["node", str(HIER / "flow_referentie.js")],
            input=json.dumps(cases), capture_output=True, text=True, check=True,
        )
        resultaat = json.loads(uit.stdout)
        fouten = [(c, g, v) for c, g, v, in zip(cases, resultaat, verwacht) if g != v]
        self.assertEqual(fouten, [], f"{len(fouten)} verschillen met de flow")


if __name__ == "__main__":
    unittest.main()
