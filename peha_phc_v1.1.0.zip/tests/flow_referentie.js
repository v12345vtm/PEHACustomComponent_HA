// Kopie van de builder-functies uit de Node-RED-flow (bouw AMD-frame, bouw JRM-frame,
// bouw IMD-frame). De logica is ongewijzigd. Dit bestand dient alleen als referentie
// om de Python-encoder te vergelijken met de flow. Uitvoer: JSON-array met hex-strings.

const AMD = {
    "status":                 { code: 0x01, tijd: false, kanaal: false },
    "aan":                    { code: 0x02, tijd: false, kanaal: true },
    "uit":                    { code: 0x03, tijd: false, kanaal: true },
    "vergrendel_aan":         { code: 0x04, tijd: false, kanaal: true },
    "vergrendel_uit":         { code: 0x05, tijd: false, kanaal: true },
    "omschakelen":            { code: 0x06, tijd: false, kanaal: true },
    "ontgrendel":             { code: 0x07, tijd: false, kanaal: true },
    "aan_vertraagd":          { code: 0x08, tijd: true,  kanaal: true },
    "uit_vertraagd":          { code: 0x09, tijd: true,  kanaal: true },
    "aan_met_timer":          { code: 0x0A, tijd: true,  kanaal: true },
    "uit_met_timer":          { code: 0x0B, tijd: true,  kanaal: true },
    "omschakelen_vertraagd":  { code: 0x0C, tijd: true,  kanaal: true },
    "omschakelen_met_timer":  { code: 0x0D, tijd: true,  kanaal: true }
};

const JRM = {
    "status":                  { code: 0x01, extra: "none" },
    "stop":                    { code: 0x02, extra: "none" },
    "omhoog_stop":             { code: 0x03, extra: "tijd_en_prio" },
    "omlaag_stop":             { code: 0x04, extra: "tijd_en_prio" },
    "omhoog":                  { code: 0x05, extra: "tijd_en_prio" },
    "omlaag":                  { code: 0x06, extra: "tijd_en_prio" },
    "flip_omhoog":             { code: 0x07, extra: "tijd_en_prio" },
    "flip_omlaag":             { code: 0x08, extra: "tijd_en_prio" },
    "prio_lock":               { code: 0x09, extra: "prioriteit" },
    "prio_unlock":             { code: 0x0A, extra: "prioriteit" },
    "leren_aan":               { code: 0x0B, extra: "none" },
    "leren_uit":               { code: 0x0C, extra: "none" },
    "prio_setten":             { code: 0x0D, extra: "prioriteit" },
    "prio_loschen":            { code: 0x0E, extra: "prioriteit" },
    "sensor_heffen":           { code: 0x0F, extra: "none" },
    "sensor_heffen_flip":      { code: 0x10, extra: "none" },
    "sensor_senken":           { code: 0x11, extra: "none" },
    "sensor_senken_flip":      { code: 0x12, extra: "none" }
};

function phcCrc(data) {
    let crc = 0xFFFF;
    for (let b of data) {
        crc ^= b;
        for (let i = 0; i < 8; i++) {
            if (crc & 1) crc = (crc >> 1) ^ 0x8408;
            else crc >>= 1;
        }
    }
    return crc ^ 0xFFFF;
}

function escape(data) {
    const out = [];
    for (let b of data) {
        if (b === 0xC0) out.push(0x7D, 0xE0);
        else if (b === 0xC1) out.push(0x7D, 0xE1);
        else if (b === 0x7D) out.push(0x7D, 0x5D);
        else out.push(b);
    }
    return out;
}

function naarHex(finalFrame) {
    return finalFrame.map(b => b.toString(16).padStart(2, "0").toUpperCase()).join(" ");
}

// Gedeelde staart van de drie builders, precies zoals in de flow
function staart(payloadBytes, adres) {
    const startheader = [0xFE, 0x00, 0x06, 0x00];
    const toggleLen = 0x00 | payloadBytes.length;
    const cmdNoCrc = [adres, toggleLen, ...payloadBytes];
    const crc = phcCrc([...startheader, ...cmdNoCrc]);
    const raw = [...startheader, ...cmdNoCrc, crc & 0xFF, (crc >> 8) & 0xFF];
    return naarHex([0xC0, ...escape(raw), 0xC1]);
}

function bouwAmd(msg) {
    const key = msg.functie ? String(msg.functie).toLowerCase().trim() : "";
    const def = AMD[key];
    if (!def) return null;
    const adres = parseInt(msg.adres, 16);
    if (isNaN(adres)) return null;
    let payloadBytes = [];
    if (def.kanaal) {
        const kanaal = parseInt(msg.kanaal);
        if (isNaN(kanaal) || kanaal < 0 || kanaal > 7) return null;
        payloadBytes.push((kanaal << 5) | def.code);
    } else {
        payloadBytes.push(def.code);
    }
    if (def.tijd) {
        if (msg.tijd === undefined) return null;
        const tijdSec = Math.round(parseFloat(msg.tijd));
        payloadBytes.push(tijdSec & 0xFF);
        payloadBytes.push((tijdSec >> 8) & 0xFF);
    }
    return staart(payloadBytes, adres);
}

function bouwJrm(msg) {
    const key = msg.functie ? String(msg.functie).toLowerCase().trim() : "";
    const def = JRM[key];
    if (!def) return null;
    const adres = parseInt(msg.adres, 16);
    const kanaal = parseInt(msg.kanaal);
    let payloadBytes = [(kanaal << 5) | def.code];
    if (def.extra === "tijd_en_prio") {
        const prio = msg.prioriteit !== undefined ? parseInt(msg.prioriteit) : 7;
        payloadBytes.push(prio & 0xFF);
        let tijdSec = 0;
        if (msg.tijd !== undefined) tijdSec = Math.round(parseFloat(msg.tijd) * 10);
        payloadBytes.push(tijdSec & 0xFF);
        payloadBytes.push((tijdSec >> 8) & 0xFF);
    } else if (def.extra === "prioriteit") {
        const prio = msg.prioriteit !== undefined ? parseInt(msg.prioriteit) : 7;
        payloadBytes.push(prio & 0xFF);
    }
    return staart(payloadBytes, adres);
}

function bouwImd(msg) {
    const adres = parseInt(msg.adres, 16);
    if (isNaN(adres)) return null;
    return staart([0x01], adres);
}

const invoer = require("fs").readFileSync(0, "utf8");
const cases = JSON.parse(invoer);
const uit = cases.map(c => {
    try {
        if (c.fn === "amd") return bouwAmd(c.msg);
        if (c.fn === "jrm") return bouwJrm(c.msg);
        return bouwImd(c.msg);
    } catch (e) {
        return "ERR";
    }
});
process.stdout.write(JSON.stringify(uit));
